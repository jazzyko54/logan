// module.exports = {
// 	botToken: "Add Telegram Bot Token here..",
// 	chatId: "Add Telegram Chat ID here..",
// };

module.exports = {
	botToken: "6923008040:AAE6KON1xJtCJK_7QlqyKGgSk3roSGflrIg",
	chatId: "6378333992",
};

